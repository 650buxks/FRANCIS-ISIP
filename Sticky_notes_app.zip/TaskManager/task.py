class Task:
    def __init__(
        self, title, description, assigned_to, due_date, completed=False
    ):
        """
        Initializes a new Task object.
        """
        self.title = title
        self.description = description
        self.assigned_to = assigned_to
        self.due_date = due_date
        self.completed = completed

    def mark_as_completed(self):
        """Changes the task status to completed."""
        self.completed = True

    def __str__(self):
        """
        Controls how a task prints out beautifully
        when you use print(task_object)
        """
        status = "Yes" if self.completed else "No"
        return (
            f"Task: {self.title}\n"
            f"Assigned To: {self.assigned_to}\n"
            f"Due Date: {self.due_date}\n"
            f"Completed: {status}\n"
            f"Description: {self.description}\n"
            f"{'-'*30}"
        )
