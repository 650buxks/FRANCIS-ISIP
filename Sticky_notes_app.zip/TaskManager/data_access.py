from task import Task


class FileHandler:

    def __init__(self, task_file="tasks.txt"):
        self.task_file = task_file

    def load_tasks(self):
        """Reads tasks.txt and turns text lines into a list of Task objects."""
        tasks = []
        try:
            with open(self.task_file, "r") as file:
                for line in file:
                    if not line.strip():
                        continue
                    parts = line.strip().split(",")
                    if len(parts) == 5:
                        title, desc, assigned, due, completed_str = parts
                        completed = completed_str.lower() == "true"

                        # Rebuilding it as a professional Task object!
                        task_obj = Task(title, desc, assigned, due, completed)
                        tasks.append(task_obj)
        except FileNotFoundError:
            # If the file doesn't exist yet, just return an empty list
            return []
        return tasks

    def save_tasks(self, tasks):
        """Takes a list of Task objects and writes them back to tasks.txt."""
        with open(self.task_file, "w") as file:
            for task in tasks:
                line = (
                    f"{task.title},{task.description},{task.assigned_to},"
                    f"{task.due_date},{task.completed}\n"
                )
                file.write(line)
