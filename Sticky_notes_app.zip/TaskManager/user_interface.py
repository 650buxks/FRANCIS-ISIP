from task import Task


class ConsoleUI:

    def __init__(self, logic_engine):
        self.logic = logic_engine

    def display_menu(self):
        """Prints the main options out to the terminal screen."""
        print("\n=== TASK MANAGER ===")
        print("1. View All Tasks")
        print("2. Add a New Task")
        print("3. Mark a Task Complete")
        print("4. Delete a Task")
        print("5. Exit")

    def run(self):
        """Runs the primary interaction loop for the user."""
        while True:
            self.display_menu()
            choice = input("\nEnter your choice (1-5): ").strip()

            if choice == "1":
                self.show_tasks()
            elif choice == "2":
                self.prompt_new_task()
            elif choice == "3":
                self.prompt_complete_task()
            elif choice == "4":
                self.prompt_delete_task()
            elif choice == "5":
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Please pick a number from 1 to 5.")

    def show_tasks(self):
        """Fetches tasks and displays them with a clean selection number."""
        tasks = self.logic.get_all_tasks()
        if not tasks:
            print("\nNo tasks found.")
            return

        print("\n--- Current Tasks ---")
        for index, task in enumerate(tasks, 1):
            print(f"[{index}] {task.title} | Completed: {task.completed}")

    def prompt_new_task(self):
        """Asks the user for input details to build a new task object."""
        title = input("Enter task title: ")
        desc = input("Enter task description: ")
        assigned = input("Assign this task to: ")
        due = input("Enter due date (YYYY-MM-DD): ")

        new_task = Task(title, desc, assigned, due)
        success, message = self.logic.add_task(new_task)
        print(message)

    def prompt_complete_task(self):
        """Asks for a task index number to mark complete."""
        self.show_tasks()
        tasks = self.logic.get_all_tasks()
        if not tasks:
            return

        try:
            choice = int(input("\nEnter the number of the task to complete: "))
            index = choice - 1  # Convert to 0-based index

            if self.logic.mark_task_complete_by_index(index):
                print(f"Success! Task #{choice} is marked complete.")
            else:
                print("Error: That task number does not exist.")
        except ValueError:
            print("Invalid entry. Please type a valid list number.")

    def prompt_delete_task(self):
        """Asks for a task index number to delete from storage."""
        self.show_tasks()
        tasks = self.logic.get_all_tasks()
        if not tasks:
            return

        try:
            choice = int(input("\nEnter the number of the task to delete: "))
            index = choice - 1

            success, message = self.logic.delete_task_by_index(index)
            print(message)
        except ValueError:
            print("Invalid entry. Please type a valid list number.")
