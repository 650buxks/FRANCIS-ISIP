import unittest
from task import Task
from business_logic import TaskManagerLogic


class MockFileHandler:
    """A fake file handler to isolate our tests from actual text files."""
    def load_tasks(self):
        return []  # Start with an empty list in-memory

    def save_tasks(self, tasks):
        pass  # Do nothing; don't write to a real disk


class TestTaskManager(unittest.TestCase):

    def setUp(self):
        """Runs before every single test case to give us a fresh setup."""
        self.mock_db = MockFileHandler()
        self.manager = TaskManagerLogic(file_handler=self.mock_db)

    # Use Case 1: Test that a valid task can be added successfully
    def test_add_task_success(self):
        new_task = Task("Buy Milk", "Need whole milk", "John", "2026-06-15")
        success, message = self.manager.add_task(new_task)
        self.assertTrue(success)
        self.assertEqual(len(self.manager.get_all_tasks()), 1)

    # Use Case 2: Test that an empty task title is rejected by logic
    def test_add_task_empty_title(self):
        bad_task = Task("   ", "No title here", "John", "2026-06-15")
        success, message = self.manager.add_task(bad_task)
        self.assertFalse(success)
        self.assertIn("cannot be empty", message)

    # Use Case 3: Test successfully marking an existing task complete by index
    def test_mark_task_complete_by_index_success(self):
        task = Task("Gym", "Leg day", "Francis", "2026-06-10")
        self.manager.add_task(task)

        # Act using the 0-based index system
        success = self.manager.mark_task_complete_by_index(0)

        # Assert
        self.assertTrue(success)
        self.assertTrue(self.manager.get_all_tasks()[0].completed)

    # Use Case 4: Test successfully deleting a task by index
    def test_delete_task_success(self):
        task = Task("Gym", "Leg day", "Francis", "2026-06-10")
        self.manager.add_task(task)

        # Act using the new delete system
        success, message = self.manager.delete_task_by_index(0)

        # Assert
        self.assertTrue(success)
        self.assertEqual(len(self.manager.get_all_tasks()), 0)
