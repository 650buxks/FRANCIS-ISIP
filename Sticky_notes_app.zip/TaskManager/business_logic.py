from data_access import FileHandler


class TaskManagerLogic:

    def __init__(self, file_handler=None):
        # If no file handler is passed, we use the default one
        self.dh = file_handler if file_handler else FileHandler()
        self.tasks = self.dh.load_tasks()

    def get_all_tasks(self):
        """Returns the current list of all tasks."""
        return self.tasks

    def add_task(self, task_obj):
        """Validates and adds a new task object to the system."""
        if not task_obj.title.strip():
            return False, "Task title cannot be empty."

        self.tasks.append(task_obj)
        self.dh.save_tasks(self.tasks)
        return True, "Task added successfully."

    def mark_task_complete(self, task_title):
        """Finds a task by its title and marks it complete."""
        for task in self.tasks:
            if task.title.lower() == task_title.lower():
                task.mark_as_completed()
                self.dh.save_tasks(self.tasks)
                return True
        return False

    def mark_task_complete_by_index(self, index):
        """Marks a task complete using its display index (0-based)."""
        if 0 <= index < len(self.tasks):
            self.tasks[index].mark_as_completed()
            self.dh.save_tasks(self.tasks)
            return True
        return False

    def delete_task_by_index(self, index):
        """Removes a task from the collection using its display index."""
        if 0 <= index < len(self.tasks):
            removed_task = self.tasks.pop(index)
            self.dh.save_tasks(self.tasks)
            return True, f"Success! Removed task: '{removed_task.title}'"
        return False, "Error: Invalid task selection number."
