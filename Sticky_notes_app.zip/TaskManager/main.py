from business_logic import TaskManagerLogic
from user_interface import ConsoleUI


def main():
    # 1. Start up the backend core logic engine
    engine = TaskManagerLogic()

    # 2. Hand that engine over to the user interface department
    ui = ConsoleUI(engine)

    # 3. Turn the key and run the application loop
    ui.run()


if __name__ == "__main__":
    main()
